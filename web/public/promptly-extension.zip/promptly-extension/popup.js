"use strict";
(() => {
  // src/shared.ts
  var DEFAULT_API_BASE = "https://promptly-api.vercel.app";
  var DEFAULT_SITE_BASE = "https://promptly-web-ecru.vercel.app";
  var MODE_LABELS = { improve: "Improve", grammar: "Grammar only", concise: "Concise" };
  var DEFAULT_SETTINGS = { enabled: true, disabledSites: [], mode: "improve", apiBase: DEFAULT_API_BASE, siteBase: DEFAULT_SITE_BASE };
  async function getSettings() {
    const { enabled, disabledSites, mode } = await chrome.storage.sync.get({
      enabled: DEFAULT_SETTINGS.enabled,
      disabledSites: DEFAULT_SETTINGS.disabledSites,
      mode: DEFAULT_SETTINGS.mode
    });
    return { enabled, disabledSites, mode, apiBase: DEFAULT_API_BASE, siteBase: DEFAULT_SITE_BASE };
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  async function currentHost() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
      const u = new URL(tab?.url || "");
      return u.protocol.startsWith("http") ? u.host : null;
    } catch {
      return null;
    }
  }
  function renderStatus(s, host) {
    const on = s.enabled && !!host && !s.disabledSites.includes(host);
    $("status").textContent = !s.enabled ? "Turned off" : !host ? "Not available on this page" : on ? "Active on this page" : "Off on this site";
    $("siteHint").textContent = host ? "Enable on this site" : "Chrome doesn't allow extensions here";
    $("siteRow").classList.toggle("disabled", !s.enabled || !host);
    $("siteEnabled").disabled = !s.enabled || !host;
  }
  async function loadAccount() {
    const me = await chrome.runtime.sendMessage({ type: "me" });
    const usageEl = $("usage");
    if (!me || me.error) {
      usageEl.textContent = "Can't reach the Promptly server.";
      usageEl.style.color = "#c01d66";
      return;
    }
    const u = me.usage;
    if (me.signedIn) {
      usageEl.textContent = u.remaining === null ? "Unlimited refinements" : `${u.remaining} left today`;
      $("signedIn").hidden = false;
      $("email").textContent = me.email || "Signed in";
    } else {
      const pct = u.limit ? u.used / u.limit * 100 : 0;
      usageEl.innerHTML = `${u.remaining} of ${u.limit} free refinements left<div class="bar"><i style="width:${pct}%"></i></div>`;
      $("login").hidden = !me.authEnabled;
    }
  }
  (async () => {
    const s = await getSettings();
    const host = await currentHost();
    const enabled = $("enabled");
    const siteEnabled = $("siteEnabled");
    const mode = $("mode");
    enabled.checked = s.enabled;
    $("siteName").textContent = host || "This page";
    siteEnabled.checked = !!host && !s.disabledSites.includes(host);
    mode.innerHTML = Object.entries(MODE_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("");
    mode.value = s.mode;
    renderStatus(s, host);
    enabled.addEventListener("change", async () => {
      s.enabled = enabled.checked;
      await chrome.storage.sync.set({ enabled: s.enabled });
      renderStatus(s, host);
    });
    siteEnabled.addEventListener("change", async () => {
      if (!host) return;
      s.disabledSites = siteEnabled.checked ? s.disabledSites.filter((h) => h !== host) : [.../* @__PURE__ */ new Set([...s.disabledSites, host])];
      await chrome.storage.sync.set({ disabledSites: s.disabledSites });
      renderStatus(s, host);
    });
    mode.addEventListener("change", () => chrome.storage.sync.set({ mode: mode.value }));
    $("login").addEventListener("click", () => chrome.runtime.sendMessage({ type: "openLogin" }));
    $("signout").addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "signout" });
      location.reload();
    });
    $("openApp").addEventListener("click", async (e) => {
      e.preventDefault();
      const { siteBase } = await getSettings();
      chrome.tabs.create({ url: `${siteBase}/app` });
    });
    loadAccount();
  })();
})();
