"use strict";
(() => {
  // src/shared.ts
  var DEFAULT_API_BASE = "https://promptly-api.vercel.app";
  var DEFAULT_SITE_BASE = "https://promptly-web-ecru.vercel.app";
  var DEFAULT_SETTINGS = { enabled: true, disabledSites: [], mode: "improve", apiBase: DEFAULT_API_BASE, siteBase: DEFAULT_SITE_BASE };
  async function getSettings() {
    const { enabled, disabledSites, mode } = await chrome.storage.sync.get({
      enabled: DEFAULT_SETTINGS.enabled,
      disabledSites: DEFAULT_SETTINGS.disabledSites,
      mode: DEFAULT_SETTINGS.mode
    });
    return { enabled, disabledSites, mode, apiBase: DEFAULT_API_BASE, siteBase: DEFAULT_SITE_BASE };
  }

  // src/background.ts
  async function deviceId() {
    const { deviceId: deviceId2 } = await chrome.storage.local.get("deviceId");
    if (typeof deviceId2 === "string") return deviceId2;
    const id = "ext" + crypto.randomUUID().replace(/-/g, "");
    await chrome.storage.local.set({ deviceId: id });
    return id;
  }
  async function getAuth() {
    const { auth } = await chrome.storage.local.get("auth");
    return auth || null;
  }
  async function refreshAuth(apiBase, auth) {
    try {
      const res = await fetch(`${apiBase}/api/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: auth.refresh_token })
      });
      if (!res.ok) throw new Error("refresh failed");
      const next = await res.json();
      const merged = { ...next, email: next.email ?? auth.email };
      await chrome.storage.local.set({ auth: merged });
      return merged;
    } catch {
      await chrome.storage.local.remove("auth");
      return null;
    }
  }
  async function api(path, init = {}) {
    const { apiBase } = await getSettings();
    let auth = await getAuth();
    if (auth && auth.expires_at * 1e3 < Date.now() + 6e4) auth = await refreshAuth(apiBase, auth);
    const send = async (a) => {
      const headers = { "Content-Type": "application/json", "X-Device-Id": await deviceId() };
      if (a) headers.Authorization = `Bearer ${a.access_token}`;
      const res = await fetch(`${apiBase}${path}`, { ...init, headers });
      return { status: res.status, data: await res.json().catch(() => ({})) };
    };
    let r = await send(auth);
    if (r.status === 401 && auth) {
      auth = await refreshAuth(apiBase, auth);
      r = await send(auth);
    }
    return r;
  }
  async function handle(msg, sender) {
    const settings = await getSettings();
    switch (msg.type) {
      case "refine": {
        try {
          const { status, data } = await api("/api/refine", {
            method: "POST",
            body: JSON.stringify({ text: msg.text, mode: msg.mode ?? settings.mode })
          });
          if (status >= 400) return { ok: false, error: data.error || "error", message: data.message || `Error ${status}`, usage: data.usage };
          return { ok: true, ...data };
        } catch {
          return { ok: false, error: "network", message: "Can't reach Promptly right now. Check your connection and try again." };
        }
      }
      case "me": {
        try {
          const { data } = await api("/api/me");
          const auth = await getAuth();
          return { ...data, email: auth?.email ?? data.email ?? null };
        } catch {
          return { error: "network" };
        }
      }
      case "auth": {
        const origin = sender.tab?.url ? new URL(sender.tab.url).origin : "";
        if (origin !== new URL(settings.siteBase).origin) return { ok: false };
        await chrome.storage.local.set({ auth: msg.payload });
        return { ok: true };
      }
      case "signout":
        await chrome.storage.local.remove("auth");
        return { ok: true };
      case "openLogin":
        await chrome.tabs.create({ url: `${settings.siteBase}/login?ext=1` });
        return { ok: true };
    }
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    handle(msg, sender).then(sendResponse);
    return true;
  });
  chrome.commands.onCommand.addListener(async (command, tab) => {
    if (command === "improve-prompt" && tab?.id) chrome.tabs.sendMessage(tab.id, { type: "shortcut" }).catch(() => {
    });
  });
  async function injectIntoOpenTabs() {
    const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
    await Promise.all(
      tabs.map(
        (t) => t.id ? chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ["content.js"] }).catch(() => {
        }) : null
      )
    );
  }
  chrome.runtime.onInstalled.addListener(async ({ reason }) => {
    await deviceId();
    await chrome.storage.sync.remove(["apiBase", "siteBase"]);
    await injectIntoOpenTabs();
    if (reason === "install") {
      const { siteBase } = await getSettings();
      chrome.tabs.create({ url: `${siteBase}/app?welcome=extension` }).catch(() => {
      });
    }
  });
})();
